<?php

namespace App\Controllers;

use App\Models\UserModel;
use CodeIgniter\Exceptions\PageNotFoundException;
use CodeIgniter\HTTP\Files\UploadedFile;

class Users extends BaseController
{
    protected $helpers = ['form'];

    /** Public folder (inside /public) that holds prepared avatars. */
    private const AVATAR_DIR = 'uploads/avatars/';

    /** Thumbnail size in pixels (square). */
    private const AVATAR_SIZE = 150;

    private function rules(?int $id = null): array
    {
        // On create there is no id yet, so the plain unique rule is used.
        $unique = $id === null
            ? 'is_unique[users.username]'
            : 'is_unique[users.username,id,' . $id . ']';

        return [
            'username' => [
                'label'  => 'Username',
                'rules'  => 'required|max_length[50]|' . $unique,
                'errors' => ['is_unique' => 'That username is already taken.'],
            ],
            'full_name' => [
                'label' => 'Full name',
                'rules' => 'required|max_length[100]',
            ],
        ];
    }

    private function avatarRules(): array
    {
        return [
            'avatar' => [
                'label'  => 'Profile picture',
                'rules'  => 'is_image[avatar]'
                          . '|mime_in[avatar,image/jpg,image/jpeg,image/png]'
                          . '|ext_in[avatar,jpg,jpeg,png]'
                          . '|max_size[avatar,2048]', // 2048 KB = 2 MB
                'errors' => [
                    'is_image' => 'The profile picture must be a valid image.',
                    'mime_in'  => 'The profile picture must be a JPG or PNG file.',
                    'ext_in'   => 'The profile picture must be a JPG or PNG file.',
                    'max_size' => 'The profile picture must not be larger than 2MB.',
                ],
            ],
        ];
    }

    public function index()
    {
        $userModel = new UserModel();

        $data['users'] = $userModel
            ->orderBy('id', 'ASC')
            ->findAll();

        return view('users', $data);
    }

    public function new()
    {
        return view('user_form', [
            'title'  => 'New User',
            'action' => base_url('users/create'),
            'user'   => null,
        ]);
    }

    public function create()
    {
        if (! $this->validate($this->rules())) {
            return redirect()->back()->withInput();
        }

        (new UserModel())->insert([
            'username'   => trim($this->request->getPost('username')),
            'full_name'  => trim($this->request->getPost('full_name')),
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        return redirect()->to('/users')->with('success', 'User created successfully.');
    }

    public function edit(int $id)
    {
        $user = (new UserModel())->find($id);

        if ($user === null) {
            throw PageNotFoundException::forPageNotFound('User not found.');
        }

        return view('user_form', [
            'title'  => 'Edit User',
            'action' => base_url('users/update/' . $id),
            'user'   => $user,
        ]);
    }

    public function update(int $id)
    {
        $model = new UserModel();
        $user  = $model->find($id);

        if ($user === null) {
            throw PageNotFoundException::forPageNotFound('User not found.');
        }

        $rules = $this->rules($id);

        // Only validate the avatar if a file was actually chosen.
        $file      = $this->request->getFile('avatar');
        $hasUpload = $file !== null && $file->getError() !== UPLOAD_ERR_NO_FILE;

        if ($hasUpload) {
            $rules += $this->avatarRules();
        }

        if (! $this->validate($rules)) {
            return redirect()->back()->withInput();
        }

        $data = [
            'username'  => trim($this->request->getPost('username')),
            'full_name' => trim($this->request->getPost('full_name')),
        ];

        if ($hasUpload) {
            $filename = $this->prepareAvatar($file);

            if ($filename === null) {
                return redirect()->back()->withInput()
                    ->with('errors', ['avatar' => 'The profile picture could not be processed. Please try another image.']);
            }

            $this->deleteAvatarFile($user['avatar'] ?? null);
            $data['avatar'] = $filename;
        }

        $model->update($id, $data);

        return redirect()->to('/users')->with('success', 'User updated successfully.');
    }

    /**
     * Turn the uploaded image into a square 150x150 thumbnail stored in
     * public/uploads/avatars and return ONLY the filename (or null on failure).
     */
    private function prepareAvatar(UploadedFile $file): ?string
    {
        if (! $file->isValid() || $file->hasMoved()) {
            return null;
        }

        $dir = FCPATH . self::AVATAR_DIR;
        if (! is_dir($dir) && ! mkdir($dir, 0775, true) && ! is_dir($dir)) {
            return null;
        }

        // Random server-generated name; extension taken from the detected MIME type.
        $ext      = $file->guessExtension() === 'png' ? 'png' : 'jpg';
        $filename = 'avatar_' . bin2hex(random_bytes(8)) . '.' . $ext;

        try {
            \Config\Services::image()
                ->withFile($file->getTempName())
                ->fit(self::AVATAR_SIZE, self::AVATAR_SIZE, 'center')
                ->save($dir . $filename, 90);
        } catch (\Throwable $e) {
            log_message('error', 'Avatar processing failed: ' . $e->getMessage());
            return null;
        }

        return $filename;
    }

    private function deleteAvatarFile(?string $filename): void
    {
        if ($filename === null || $filename === '') {
            return;
        }

        $path = FCPATH . self::AVATAR_DIR . basename($filename);

        if (is_file($path)) {
            @unlink($path);
        }
    }
}
