<?php
$errors   = session('errors') ?? [];
$val      = static fn (string $f) => old($f, $user[$f] ?? '');
$isEdit   = $user !== null;
$avatar   = $isEdit && ! empty($user['avatar'])
    ? base_url('uploads/avatars/' . $user['avatar'])
    : base_url('assets/img/avatar-placeholder.svg');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="<?= base_url('assets/css/valorant.css') ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title) ?></title>
</head>
<body>
    <nav>
        <a href="<?= base_url() ?>">Home</a> |
        <a href="<?= base_url('about') ?>">About</a> |
        <a href="<?= base_url('customers') ?>">Customer Accounts</a> |
        <a href="<?= base_url('users') ?>">User Accounts</a>
    </nav>

    <hr>

    <div class="container">
        <h1><?= esc($title) ?></h1>

        <?php if ($errors): ?>
            <div class="alert alert-error">
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?= esc($error) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?= $action ?>" method="post" enctype="multipart/form-data" novalidate>
            <?= csrf_field() ?>

            <div class="form-group">
                <label for="username">Username *</label>
                <input type="text" id="username" name="username" maxlength="50" value="<?= esc($val('username')) ?>">
            </div>

            <div class="form-group">
                <label for="full_name">Full Name *</label>
                <input type="text" id="full_name" name="full_name" maxlength="100" value="<?= esc($val('full_name')) ?>">
            </div>

            <?php if ($isEdit): ?>
                <div class="form-group">
                    <label for="avatar">Profile Picture</label>
                    <div class="avatar-edit">
                        <img src="<?= $avatar ?>" alt="Current avatar" class="avatar">
                        <div>
                            <input type="file" id="avatar" name="avatar" accept=".jpg,.jpeg,.png,image/jpeg,image/png">
                            <small>JPG or PNG, maximum 2MB. Leave empty to keep the current picture.</small>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <div class="form-actions">
                <button type="submit" class="btn">Save</button>
                <a href="<?= base_url('users') ?>" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</body>
</html>
